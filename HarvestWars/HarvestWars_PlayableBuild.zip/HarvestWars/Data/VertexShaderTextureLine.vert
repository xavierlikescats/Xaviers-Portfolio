{
    "shader": "#version 330\nlayout (location = 0) in vec2 pos;\nlayout (location = 1) in vec2 uv;\n uniform mat4 MVP;\n uniform int numSegment = 1;\n out vec2 texCoord;\n void main()\n{\n    gl_Position = MVP * vec4(pos, 0.0, 1.0);\n texCoord.x = uv.x * numSegment;   texCoord.y = uv.y; gl_PointSize = 10.0;\n}\n"
}
