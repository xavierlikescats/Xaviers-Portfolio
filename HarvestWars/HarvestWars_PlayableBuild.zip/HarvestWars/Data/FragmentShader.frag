{
    "shader": "#version 330\nin vec2 texCoord;\nout vec4 fragmentColor;\nuniform sampler2D inTexture;\nuniform vec4 color;\nvoid main(void) \n{\n    vec4 texColor = texture(inTexture, texCoord);\n    if (texColor.a < 0.1) discard;\n    fragmentColor = texColor * color;\n}\n"
}
