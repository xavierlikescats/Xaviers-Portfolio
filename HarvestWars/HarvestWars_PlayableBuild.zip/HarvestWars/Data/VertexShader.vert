{
    "shader": "#version 330\nlayout (location = 0) in vec2 pos;\nlayout (location = 1) in vec2 uv;\n uniform mat4 MVP;\nout vec2 texCoord;\n void main()\n{\n    gl_Position = MVP * vec4(pos, 0.0, 1.0);\n    texCoord = uv; gl_PointSize = 10.0;\n}\n"
}
