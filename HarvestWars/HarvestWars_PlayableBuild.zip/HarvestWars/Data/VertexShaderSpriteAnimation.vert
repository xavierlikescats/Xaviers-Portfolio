{
    "shader": "#version 330\nlayout (location = 0) in vec2 pos;\nlayout (location = 1) in vec2 uv;\n uniform mat4 MVP;\n uniform vec2 texPos;\n uniform vec2 uvSize;\n out vec2 texCoord;\n void main()\n{\n    gl_Position = MVP * vec4(pos, 0.0, 1.0);\n texCoord.x = texPos.x + uv.x * uvSize.x;   texCoord.y = texPos.y + uv.y * uvSize.y;}\n"
}
