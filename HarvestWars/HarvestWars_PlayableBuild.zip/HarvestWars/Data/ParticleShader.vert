#version 330 core

layout (location = 0) in vec2 pos;
layout (location = 1) in vec2 uv;
layout (location = 2) in vec4 color;

uniform mat4 MVP;

out vec2 Frag_UV;
out vec4 Frag_Color;

void main()
{
    Frag_UV = uv;
    Frag_Color = color;
    gl_Position = MVP * vec4(pos, 0.0, 1.0);
}